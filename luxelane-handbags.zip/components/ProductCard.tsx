import React, { useContext } from 'react';
import { AppContext } from '../context/AppContext';
import type { Product } from '../types';
import Button from './ui/Button';

interface ProductCardProps {
  product: Product;
  onEdit: (product: Product) => void;
  onDelete: (productId: string) => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onEdit, onDelete }) => {
  const { isAdmin, addToCart } = useContext(AppContext);

  return (
    <div className="group relative border border-gray-200 rounded-lg overflow-hidden transition-shadow hover:shadow-lg flex flex-col">
      <div className="aspect-w-1 aspect-h-1 w-full overflow-hidden bg-gray-200">
        <img
          src={product.imageUrl}
          alt={product.name}
          className="h-full w-full object-cover object-center transition-transform group-hover:scale-105"
        />
      </div>
      <div className="p-4 flex flex-col flex-grow">
        <h3 className="text-md font-semibold text-gray-800 truncate">{product.name}</h3>
        <p className="text-lg font-bold text-primary mt-1">${product.price.toFixed(2)}</p>
         <div className="mt-4 pt-4 border-t border-gray-100">
            {isAdmin ? (
              <div className="flex space-x-2">
                <Button variant="secondary" className="w-full text-sm" onClick={() => onEdit(product)}>Edit</Button>
                <Button variant="danger" className="w-full text-sm" onClick={() => onDelete(product.id)}>Delete</Button>
              </div>
            ) : (
                <Button className="w-full" onClick={() => addToCart(product)}>Add to Cart</Button>
            )}
         </div>
      </div>
    </div>
  );
};

export default ProductCard;