
import React, { useState, useEffect, useContext, FormEvent } from 'react';
import type { Product } from '../types';
import { AppContext } from '../context/AppContext';
import { generateDescription } from '../services/geminiService';
import { HANDBAG_IMAGE_URLS } from '../constants';
import Modal from './ui/Modal';
import Input from './ui/Input';
import Button from './ui/Button';

interface ProductFormProps {
  isOpen: boolean;
  onClose: () => void;
  product: Product | null;
}

const ProductForm: React.FC<ProductFormProps> = ({ isOpen, onClose, product }) => {
  const { categories, addProduct, updateProduct } = useContext(AppContext);
  const [formData, setFormData] = useState<Omit<Product, 'id'>>({
    name: '',
    price: 0,
    imageUrl: '',
    description: '',
    category: '',
  });
  const [isGenerating, setIsGenerating] = useState(false);
  const [imageError, setImageError] = useState(false);

  useEffect(() => {
    setImageError(false); // Reset error on open/product change
    if (product) {
      setFormData({ ...product });
    } else {
      // Reset form for new product
      setFormData({
        name: '',
        price: 0,
        // Use a reliable, random image from our curated list as the default
        imageUrl: HANDBAG_IMAGE_URLS[Math.floor(Math.random() * HANDBAG_IMAGE_URLS.length)],
        description: '',
        category: categories.find(c => c.name !== 'All Handbags')?.name || '',
      });
    }
  }, [product, isOpen, categories]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    if (name === 'imageUrl') {
      setImageError(false); // Reset image error when user starts typing a new URL
    }
    setFormData(prev => ({ ...prev, [name]: name === 'price' ? parseFloat(value) : value }));
  };

  const handleGenerateDescription = async () => {
    if (!formData.name) {
      alert('Please enter a product name first.');
      return;
    }
    setIsGenerating(true);
    const desc = await generateDescription(formData.name);
    setFormData(prev => ({ ...prev, description: desc }));
    setIsGenerating(false);
  };
  
  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if(product) { // Editing existing product
      updateProduct({ id: product.id, ...formData });
    } else { // Adding new product
      addProduct({ id: `prod-${Date.now()}`, ...formData });
    }
    onClose();
  };

  const availableCategories = categories.filter(c => c.name !== 'All Handbags');

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={product ? 'Edit Product' : 'Add New Product'}>
      <form onSubmit={handleSubmit} className="space-y-4">
        <Input label="Product Name" name="name" value={formData.name} onChange={handleChange} required />
        <Input label="Price" name="price" type="number" step="0.01" value={formData.price} onChange={handleChange} required />
        <Input label="Image URL" name="imageUrl" value={formData.imageUrl} onChange={handleChange} required />
        
        {/* --- LIVE IMAGE PREVIEW --- */}
        {formData.imageUrl && (
            <div className="mt-2 p-2 border rounded-md flex justify-center items-center bg-gray-50 h-40">
                {imageError ? (
                    <div className="text-center text-red-600">
                        <svg xmlns="http://www.w3.org/2000/svg" className="mx-auto h-8 w-8 text-red-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                           <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <p className="text-sm mt-1">Image failed to load.<br/>Please check the URL.</p>
                    </div>
                ) : (
                    <img 
                        src={formData.imageUrl} 
                        alt="Product preview"
                        className="max-h-full max-w-full object-contain rounded"
                        onError={() => setImageError(true)}
                        onLoad={() => setImageError(false)} // In case a previously broken URL is fixed
                    />
                )}
            </div>
        )}
        
        <div>
          <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">Description</label>
          <textarea
            id="description"
            name="description"
            rows={4}
            className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
            value={formData.description}
            onChange={handleChange}
            required
          ></textarea>
        </div>

        <Button type="button" variant="secondary" onClick={handleGenerateDescription} disabled={isGenerating}>
          {isGenerating ? 'Generating...' : 'Generate Description with AI ✨'}
        </Button>
        
        <div>
          <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-1">Category</label>
          <select
            id="category"
            name="category"
            className="block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm rounded-md"
            value={formData.category}
            onChange={handleChange}
            required
          >
            <option value="" disabled>Select a category</option>
            {availableCategories.map(cat => (
              <option key={cat.id} value={cat.name}>{cat.name}</option>
            ))}
          </select>
        </div>

        <div className="flex justify-end space-x-2 pt-4">
          <Button type="button" variant="secondary" onClick={onClose}>Cancel</Button>
          <Button type="submit">{product ? 'Save Changes' : 'Add Product'}</Button>
        </div>
      </form>
    </Modal>
  );
};

export default ProductForm;