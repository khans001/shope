import React, { useState, useContext, useEffect } from 'react';
import type { View } from './types';
import { AppContext } from './context/AppContext';
import Header from './components/Header';
import Footer from './components/Footer';
import ProductGrid from './components/ProductGrid';
import AdminLogin from './components/AdminLogin';
import AdminPanel from './components/AdminPanel';
import Checkout from './components/Checkout';

const App: React.FC = () => {
    const [view, setView] = useState<View>('home');
    const { isAdmin, siteName } = useContext(AppContext);

    // Effect to update document title when siteName changes
    useEffect(() => {
        if (siteName) {
            document.title = siteName;
        }
    }, [siteName]);

    const renderView = () => {
        switch (view) {
            case 'adminLogin':
                return <AdminLogin setView={setView} />;
            case 'adminPanel':
                if (isAdmin) {
                    return <AdminPanel setView={setView} />;
                }
                // If not admin, redirect to login
                setView('adminLogin');
                return null;
            case 'checkout':
                return <Checkout setView={setView} />;
            case 'home':
            default:
                return <ProductGrid />;
        }
    };

    return (
        <div className="flex flex-col min-h-screen font-sans text-primary">
            <Header setView={setView} />
            <main className="flex-grow container mx-auto px-4 py-8">
                {renderView()}
            </main>
            <Footer />
        </div>
    );
};

export default App;